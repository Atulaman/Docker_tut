import streamlit as st

def Joki_lapa():
    st.header('Joki')
    ###
    st.write('Skolotāja: Bērni, kā jūs domājat, cik skola ir augsta?')
    st.write('Jānītis: 1m 50cm')
    st.write('Kapēc tu tā domā?')
    st.write('Jo skola man ir līdz kaklam!')
    st.write('----------')
    ###
    st.write('Sakiet, skolotāj, vai cilvēku var sodīt par to, ko viņš nav izdarījis?')
    st.write('Protams, ka nevar.')
    st.write('Vai cik labi ! Es neesmu sagatavojis mājas darbus!')
    st.write('----------')
    ###
    st.write('Vecāki bērniem 4.klase: ” Tu mājasdarbus izpildiji?”')
    st.write('9.klase: “Tu somu paņemi?”')
    st.write('12.klase: “Tu uz skolu iesi?”')
    st.write('----------')
    ###
    st.write('What is a witch’s favorite subject in school?')
    st.write('Spelling!')
    st.write('----------')
    ###
    st.write('Which letter of the alphabet has the most water?')
    st.write('The C')
    st.write('----------')
    ###
    st.write('What do you do if a teacher rolls her eyes at you?')
    st.write('Pick them up and roll them back!')
    st.write('----------')
    ###
    st.caption('Jokus savāca: Ernests Kazakevičs')


