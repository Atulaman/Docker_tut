import streamlit as st

def rickroll():
    st.markdown('[click here](https://youtu.be/dQw4w9WgXcQ)')