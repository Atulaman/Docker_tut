import streamlit as st

def Fakti_lapa():
    st.header('Fakti')
    ### 1
    st.write('Visgarākais cilvēks mūsu klasē ir Kārlis Zeidaks.')
    st.write('----------')
    ### 2
    st.write('Visīsakais cilvēks mūsu klasē ir Roberts Leizāns.')
    st.write('----------')
    ### 3
    st.write('Visuzticamākais cilvēks ir mūsu klases vecākais Jānis Helvijs Jaunzems.')
    st.write('----------')
    ### 4
    st.write('Visi 3 cilvēki no 10E klases, kuri piedalījās Latvijas Informātikas Olimpiāde (LIO) iesildīšanas kārtā, iekļuva LIO valsts kārtā.')
    st.write('----------')
    ### 5
    st.write('Viens cilvēks no 10E klases salauza 3D printerus gan RV1Ģ, gan IZV, kad mēģināja paveikt uzdevumu informātikā (izdrukāt savu 3D kubiņu).')
    st.write('----------')
    ### 6
    st.write('10E klases 1. dāvana klases audzinātājai A.L. bija dāvanu karte kafijas veikalā.')
    st.write('----------')
    ### 7
    st.write('Šogad 3 cilvēki no 10E klases piedalījās populārajā raidījumā “Gudrāks, vēl gudrāks” Latvijas Televīzījā.')
    st.write('----------')
    ###
    st.caption('Faktus apkopoja Veronika Lohmanova')